import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ArrayList<Employee> employees = new ArrayList<>();

        SalariedEmployee se = new SalariedEmployee("John Smith", 5000);
        HourlyEmployee he = new HourlyEmployee("Jane Doe", 15, 40);
        CommissionEmployee ce = new CommissionEmployee("Bob Johnson", 50000, 0.05);
        BasePlusCommissionEmployee bpce = new BasePlusCommissionEmployee("Sue Wilson", 60000, 0.04, 2000);
        PieceWorker pw = new PieceWorker("Mike Brown", 20, 200);

        employees.add(se);
        employees.add(he);
        employees.add(ce);
        employees.add(bpce);
        employees.add(pw);

        for (Employee employee : employees) {
            System.out.println("Name: " + employee.getName() +
                    "\nType: " + employee.getClass().getSimpleName() +
                    "\nMonthly Pay: " + employee.getPaymentAmount() + "\n");
        }
    }
}