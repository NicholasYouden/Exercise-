class BasePlusCommissionEmployee extends CommissionEmployee {
    private double baseSalary;

    public BasePlusCommissionEmployee(String name, double grossSales, double commissionRate, double baseSalary) {
        super(name, grossSales, commissionRate);
        this.baseSalary = baseSalary;
    }

    public double getPaymentAmount() {
        return super.getPaymentAmount() + baseSalary;
    }
}
