class PieceWorker extends Employee {
    private double wagePerPiece;
    private int piecesProduced;

    public PieceWorker(String name, double wagePerPiece, int piecesProduced) {
        super(name);
        this.wagePerPiece = wagePerPiece;
        this.piecesProduced = piecesProduced;
    }

    public double getPaymentAmount() {
        return wagePerPiece * piecesProduced;
    }
}