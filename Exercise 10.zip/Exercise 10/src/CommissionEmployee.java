class CommissionEmployee extends Employee {
    private double grossSales;
    private double commissionRate;

    public CommissionEmployee(String name, double grossSales, double commissionRate) {
        super(name);
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }

    public double getPaymentAmount() {
        return grossSales * commissionRate / 12;
    }
}
